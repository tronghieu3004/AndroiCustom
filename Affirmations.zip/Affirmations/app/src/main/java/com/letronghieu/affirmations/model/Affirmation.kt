package com.letronghieu.affirmations.model

import android.security.identity.AccessControlProfileId
import java.util.ListResourceBundle

data class Affirmation (val stringResourceId: Int)